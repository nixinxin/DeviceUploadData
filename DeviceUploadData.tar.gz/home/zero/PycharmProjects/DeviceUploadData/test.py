import json

aaa = """{"@timestamp":"01/Mar/2019:10:57:29+0800", "request_body":"[{"cmd":"021001","data":{"sn":3,"battery":79,"rssi":99,"time":1551169181989,"time_string":"01/03/2019:10:57:29","warn":1,"object_direction":1,"object_move":false,"ntc_temperature":25.810000,"dig_temperature":7.700000,"humidity":14.810000,"pressure":0,"x_amplitude":3793,"x_frequency":1170,"y_amplitude":9662,"y_frequency":2896,"z_amplitude":5405,"z_frequency":1300},"device_code":"002108010712211D","type":"device_data","time":1551409049790}]","@fields":{"host":"wechat.v3.api.2012iot.com","server_port":"80","remote_addr":"192.168.5.175","upstream_addr":"10.21.10.79:8080","remote_user":"","request":"POST/api-wechat/alarm/alarmServerHTTP/1.0","status":"200","upstream_status":"200","request_time":"0.472","upstream_response_time":"0.472","body_bytes_sent":"12","http_referer":"","http_user_agent":"","http_x_forwarded_for":"47.100.234.175,192.168.5.152","http_tokenStr":""}}"""
data = json.loads(aaa)
print(aaa)
