import json
import time

from pyspark import SparkContext, SparkConf
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils

# HBASE表，需要提前在HBASE中建好
table = 'device_upload_data'
broker = "Master:9092"
# kafka的topic
topic = "logfile_memory_kafka"

# HBASE的zookeeper
hbaseZK = "Master"
keyConv = "org.apache.spark.examples.pythonconverters.StringToImmutableBytesWritableConverter"
valueConv = "org.apache.spark.examples.pythonconverters.StringToImmutableBytesWritableConverter"
hbaseConf = {
    "hbase.zookeeper.quorum": hbaseZK,
    "hbase.mapred.outputtable": table,
    "mapreduce.outputformat.class": "org.apache.hadoop.hbase.mapreduce.TableOutputFormat",
    "mapreduce.job.output.key.class": "org.apache.hadoop.hbase.io.ImmutableBytesWritable",
    "mapreduce.job.output.value.class": "org.apache.hadoop.io.Writable"
}

# 打印日志
def data_log(str):
    time_format = time.strftime(r"%Y-%m-%d %H:%M:%S", time.localtime())
    return "[%s]%s" % (time_format, str)

# 处理RDD元素，此RDD元素需为字典类型
def fmt_data(msg_dict):

    # 需要将RDD中的字典的每个键值对准备成这种元组格式(rowkey, [row key, column family, column name, value])写入HBASE
    msg_dict = json.loads(msg_dict.replace(" ", "").replace('"[', "[").replace(']"', "]"))
    row_line_values = []
    for key, value in msg_dict.items():
        row_key = None
        if key == '@timestamp':
            row_key = key
        elif key == 'request_body':
            for item in value[0].items():
                pass

    return msg_dict

#处理RDD并向HBASE中写入
def connectAndWrite(data):
    if not data.isEmpty():
        # 接收到的RDD中的元素转为字典，收到的格式为(None,[json串])，所以map第二个元素反序列化成为字典类型
        device_upload_data = data.map(lambda x: x[1])
        counts = device_upload_data.count()
        # 处理RDD中元素为写入HBASE需要的格式，形成元组格式
        msg_row = device_upload_data.map(lambda x: fmt_data(x))
        msg_row.collect()
        # 将RDD中所有元素中的元组扁平化，再map后往HBASE存储
        # msg_row.saveAsNewAPIHadoopDataset(conf=hbaseConf, keyConverter=keyConv, valueConverter=valueConv)

if __name__ == '__main__':
    zkQuorum = '127.0.0.1:2181'
    groupId = '127.0.0.1:2181'

    sc = SparkContext("local[5]", appName="logfile-streaming")
    ssc = StreamingContext(sc, 10)
    kafkaStreams = KafkaUtils.createStream(ssc=ssc,
                                           zkQuorum=zkQuorum,
                                           groupId='0',
                                           topics={"logfile-memory-kafka": 1},
                                           kafkaParams={'logfile-memory-kafka': 1,
                                                        # "zookeeper.connect": zkQuorum,
                                                        # "group.id": groupId,
                                                        # "zookeeper.connection.timeout.ms": "10000",
                                            })

    kafkaStreams.foreachRDD(connectAndWrite)

    ssc.start()
    ssc.awaitTermination()


